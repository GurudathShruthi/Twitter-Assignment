import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from Intro import Introduction
from editprofile import EditProfile
from posttweet import PostTweet
from twitter import Twitter
from edittweet import EditTweet
from searchuser import SearchUser
from display import Display
from searchTweet import SearchMessage

JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)


def fetch_tweets(followingList):
    result_tweets = []
    for i in range(len(followingList)):
        tweet_key = ndb.Key('Twitter',followingList[i])
        tweet = tweet_key.get()

        for t in range(len(tweet.tweet)):
            result_tweets.append(tweet.tweet[t])
    return result_tweets

class MainPage(webapp2.RequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/html'
        user = users.get_current_user()
        if user == None:
            template_values = {
            'login_url' : users.create_login_url(self.request.uri)
            }
            template = JINJA_ENVIRONMENT.get_template('mainpage_guest.html')
            self.response.write(template.render(template_values))
            return
        myuser_key = ndb.Key('MyUser', user.user_id())
        myuser = myuser_key.get()

        if myuser == None:
            myuser = MyUser(userEmail=user.email(),id=user.user_id())
            myuser.put()

            template_values ={'myuser':myuser}
            template = JINJA_ENVIRONMENT.get_template('Intro.html')
            self.response.write(template.render(template_values))
            return

        record = myuser.followingUsers
        record.append(myuser.UserName)
        my_tweets = Twitter.query()
        my_tweets = my_tweets.filter(Twitter.UserName.IN(record))
        my_tweets = my_tweets.order(-Twitter.timeStamp)


        template_values = {
            'logout_url' : users.create_logout_url(self.request.uri),
            'user':user,
            'myuser':myuser,
            'mytweet':my_tweets.fetch(50),
            'myuser':myuser
            }

        template = JINJA_ENVIRONMENT.get_template('main.html')
        self.response.write(template.render(template_values))


    def post(self):
        self.response.headers['Content-Type'] = 'text/html'
        action = self.request.get('button')

        edit_id = str(self.request.params.items()[0][1])

        mytweet_key = ndb.Key('Twitter',edit_id)
        mytweet = mytweet_key.get()

        if action == 'DELETE':
            mytweet.key.delete()
            self.redirect('/')

        elif action == "EDIT":

            query_string = "name ={0}".format(edit_id)
            self.redirect('/edittweet?'+query_string)


app = webapp2.WSGIApplication([('/',MainPage),('/Intro',Introduction),('/posttweet',PostTweet),('/editprofile',EditProfile),
                                ('/searchuser',SearchUser),('/display',Display),('/searchTweet',SearchMessage),
                                ('/edittweet',EditTweet)],debug=True)
