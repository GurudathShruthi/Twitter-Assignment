import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from twitter import Twitter
from datetime import datetime
JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)
# Function
def findMessage(message):
    found_message =[]

    for i in Twitter.query().order(-Twitter.timeStamp):
        if message in i.tweet.split():
            found_message.append(i)
        else:
            continue
    return found_message


class SearchMessage(webapp2.RequestHandler):

    def post(self):
        self.response.headers['Content-Type'] = 'text/html'
        searchtweet = self.request.get('Search TWEET')

        found_message = findMessage(searchtweet)
        message_len = len(found_message)

        template_values= {'message_len':message_len,'found_message':found_message}
        template = JINJA_ENVIRONMENT.get_template('searchTweet.html')
        self.response.write(template.render(template_values))
