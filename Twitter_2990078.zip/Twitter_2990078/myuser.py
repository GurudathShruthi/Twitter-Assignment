from google.appengine.ext import ndb
class MyUser(ndb.Model):
    UserName = ndb.StringProperty()
    Intro = ndb.StringProperty()
    DateOfBirth = ndb.DateProperty()
    gender = ndb.StringProperty()
    Place = ndb.StringProperty()
    userEmail = ndb.StringProperty()
    followedUsers = ndb.StringProperty(repeated = True)
    followingUsers = ndb.StringProperty(repeated=True)
