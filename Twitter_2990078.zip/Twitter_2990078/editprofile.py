import webapp2
import os
import jinja2
from google.appengine.ext import ndb
from google.appengine.api import users
from myuser import MyUser
from datetime import datetime

JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)

class EditProfile(webapp2.RequestHandler):

    def get(self):
        self.response.headers['Content-Type'] = 'text/html'
        user = users.get_current_user()
        user_key = ndb.Key("MyUser",user.user_id())
        myuser = user_key.get()

        template_values ={
        'myuser' : myuser
        }

        template = JINJA_ENVIRONMENT.get_template('editprofile.html')
        self.response.write(template.render(template_values))

    def post(self):
        self.response.headers['Content-Type'] = 'text/html'
        action = self.request.get('button')


        if action == 'UPDATE':
            user = users.get_current_user()
            user_key = ndb.Key("MyUser",user.user_id())
            myuser = user_key.get()
            myuser.DateOfBirth = datetime.strptime(self.request.get('dateofbirth'), '%Y-%m-%d')
            myuser.Place = self.request.get('Place')
            myuser.gender = self.request.get('gender')
            myuser.Intro = self.request.get('message')
            myuser.put()
            self.redirect('/')
