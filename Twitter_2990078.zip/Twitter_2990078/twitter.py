from google.appengine.ext import ndb

class Twitter(ndb.Model):
    tweet = ndb.StringProperty()
    UserName = ndb.StringProperty()
    timeStamp = ndb.DateTimeProperty(auto_now=True)
