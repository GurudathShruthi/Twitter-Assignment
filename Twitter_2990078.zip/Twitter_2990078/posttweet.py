import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from Intro import Introduction
from twitter import Twitter
import calendar
import time

JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)

class PostTweet(webapp2.RequestHandler):
    def post(self):
        user = users.get_current_user()
        user_key = ndb.Key('MyUser',user.user_id())
        user_details = user_key.get()

        action = self.request.get('button')
        if action == 'POST':
            tweet_info = self.request.get('tweet');
            new_message = Twitter(UserName = user_details.UserName,id=user_details.UserName+"/"+str(calendar.timegm(time.gmtime())))
            new_message.tweet = tweet_info
            new_message.put()
            self.redirect('/')

        elif action == 'CANCEL':
            self.redirect('/')
