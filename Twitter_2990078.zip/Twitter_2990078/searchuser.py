import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from twitter import Twitter
from datetime import datetime

JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)
#

class SearchUser(webapp2.RequestHandler):
    def post(self):
        self.response.headers['Content-Type'] = 'text/html'
        search_User = self.request.get('SearchUser')


        search_result = MyUser.query().filter(MyUser.UserName==search_User).fetch(keys_only=True)
        if(len(search_result )== 0):
            message = "fail"
            template_values= {'message':message}
            template = JINJA_ENVIRONMENT.get_template('searchuser.html')
            self.response.write(template.render(template_values))

        else:
            search_key = ndb.Key('MyUser',search_result[0].id())
            searched_profile = search_key.get()
            message = "success"
            template_values= {'search':search_User,'message':message,'profile':searched_profile}
            template = JINJA_ENVIRONMENT.get_template('searchuser.html')
            self.response.write(template.render(template_values))

