import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from twitter import Twitter
from datetime import datetime
JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)

class Introduction(webapp2.RequestHandler):

    def get(self):
        message = "Welcome to the twitter application"
        user= users.get_current_user()
        template_values = {'message':message}
        template = JINJA_ENVIRONMENT.get_template('Intro.html')
        self.response.write(template.render(template_values))

    def post(self):
        action = self.request.get('button')
        user= users.get_current_user()
        if action == 'SUBMIT':

            myuser_key = ndb.Key('MyUser',user.user_id())
            myuser = myuser_key.get()

            myuser.UserName = self.request.get('username')
            myuser.DateOfBirth= datetime.strptime(self.request.get('dateofbirth'),'%Y-%m-%d')
            myuser.Place = self.request.get('Place')
            myuser.gender = self.request.get('gender')
            myuser.Intro = self.request.get('message')

            myuser.put()
            self.redirect('/')

        template_values = {'message':"User Profile Created Successfully"}
        template = JINJA_ENVIRONMENT.get_template('Intro.html')
        self.response.write(template.render(template_values))
