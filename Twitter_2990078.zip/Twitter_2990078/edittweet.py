import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from Intro import Introduction
from editprofile import EditProfile
from posttweet import PostTweet
JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)

class EditTweet(webapp2.RequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/html'
        id = self.request.params.items()[0][1]

        mytweet_key = ndb.Key('Twitter',id)
        mytweet = mytweet_key.get()

        template_values={'message' :"EDIT TWEET","tweet":mytweet.tweet,'id':id}
        template = JINJA_ENVIRONMENT.get_template('edittweet.html')
        self.response.write(template.render(template_values))

    def post(self):
        self.response.headers['Content-Type'] = 'text/html'
        action = self.request.get('button')
        id = self.request.params.items()[0][1]



        if action == 'UPDATE':
            mytweet_key = ndb.Key('Twitter',id)
            mytweet = mytweet_key.get()
            mytweet.tweet = self.request.get('tweet')
            mytweet.put()
            self.redirect('/')
        elif action == 'CANCEL':
            self.redirect('/')
