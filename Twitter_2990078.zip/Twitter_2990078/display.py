import webapp2;
import os;
import jinja2;
import random;
from google.appengine.ext import ndb;
from google.appengine.api import users
from myuser import MyUser
from twitter import Twitter
from datetime import datetime

JINJA_ENVIRONMENT = jinja2.Environment(
loader = jinja2.FileSystemLoader(os.path.dirname(__file__)),
extensions = ['jinja2.ext.autoescape'],
autoescape = True
)

def findUser(user,followingList):
    flag = False
    for UserName in range(len(followingList)):
        if str(followingList[UserName]) == user:
            flag = True
    return flag

def fetchLast_50(tweetList):
    list_len = len(tweetList)
    reverse_tweet = list(reversed(tweetList))
    result_tweet = []
    if list_len >50:
       for i in range(50):
           result_tweet.append(reverse_tweet[i])
    else:
        for i in range(list_len):
            result_tweet.append(reverse_tweet[i])

    return result_tweet



class Display(webapp2.RequestHandler):
    def get(self):
        self.response.headers['Content-Type'] = 'text/html'
        user = str(self.request.params.items()[0][1])
        present_user = users.get_current_user()
        present_user_key = ndb.Key('MyUser',present_user.user_id())
        current_user = present_user_key.get()

        query = MyUser.query()
        query = query.filter(MyUser.UserName == user).fetch(keys_only=True)
        user_id = query[0].id()


        findProfile_key = ndb.Key('MyUser',user_id)
        findProfile = findProfile_key.get()

        profile_exists = findUser(findProfile.UserName, current_user.followingUsers)


        profile_tweets = Twitter.query().filter(Twitter.UserName==findProfile.UserName).order(-Twitter.timeStamp)


        template_values = {'myuser':findProfile,
                           'exists':profile_exists,
                           'user_tweets':profile_tweets.fetch(50),
                           'current_user':current_user}

        template = JINJA_ENVIRONMENT.get_template('display.html')
        self.response.write(template.render(template_values))
#
    def post(self):
        self.response.headers['Content-Type'] = 'text/html'
        action = self.request.get('button')
        present_user = users.get_current_user()
        present_user_key = ndb.Key('MyUser',present_user.user_id())
        current_user = present_user_key.get()

        user = str(self.request.params.items()[0][1])
        query = MyUser.query()
        query = query.filter(MyUser.UserName == user).fetch(keys_only=True)
        user_id = query[0].id()


        findProfile_key = ndb.Key('MyUser',user_id)
        findProfile = findProfile_key.get()


        if action == 'FOLLOW':

            current_user.followingUsers.append(user)
            current_user.put()

            findProfile.followedUsers.append(findProfile.UserName)
            findProfile.put()


        elif action == "UNFOLLOW":

            current_user.followingUsers.remove(user)
            current_user.put()

            findProfile.followedUsers.remove(current_user.UserName)
            findProfile.put()


        query_string = "name ={0}".format(findProfile.UserName)
        self.redirect('/display?'+query_string)
